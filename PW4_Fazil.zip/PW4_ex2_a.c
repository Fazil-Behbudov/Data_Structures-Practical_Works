#include <stdio.h>
int main(int argc, char const *argv[])
{
    int n;
    printf("Enter your number: ");
    scanf("%d",&n);
    int factorial=1;
    for(int i=1;i<=n;i++){
        factorial*=i;
    }
    printf("The factorial of %d is: %d",n,factorial);
    return 0;
}
