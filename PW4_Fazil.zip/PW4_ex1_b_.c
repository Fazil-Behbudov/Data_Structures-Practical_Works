#include <stdio.h>
int finding_gcd(int m,int n,int i,int gcd){
    if(i > m || i > n){
        return gcd;
    }
    if(m%i == 0 && n%i == 0){
        gcd=i;
    }
    return finding_gcd(m,n,i+1,gcd);
}
int main(int argc, char const *argv[])
{
    int m, n, i=1, gcd;
    printf("Enter two integers: ");
    scanf("%d %d",&m,&n);
    if(m == 0 || n == 0){
        printf("The numbers can not be zero!!!!");
        return 0;
    }
    gcd=finding_gcd(m,n,i,gcd);
    printf("G.C.D of %d and %d is: %d", m, n, gcd);
    return 0;
}
