#include <stdio.h>
void secondsConverter(int x){  //the function for converting seconds to minutes and seconds.
    int min=x/60;
    int sec=x - min*60;
    printf("%d minutes,%d seconds",min,sec);
}
int main(int argc, char const *argv[])
{
    int seconds;
    printf("Enter the number of seconds: "); 

    //reads the number of seconds entered by the user
    scanf("%d",&seconds);
    
    //calls the function for converting seconds to minutes and seconds
    secondsConverter(seconds);  
    return 0;
}
