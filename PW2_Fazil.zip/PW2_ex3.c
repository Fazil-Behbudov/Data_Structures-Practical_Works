#include <stdio.h>
int main(int argc, char const *argv[])
{
    float temp;
    printf("Enter the temperature in Fahrenheit: ");

    //reads the temperature in Fahrenheit entered by the user.
    scanf("%f",&temp);
    float temp_celc=(temp-32)/9*5;
    //displays the temperature in celcius
    printf("Temperature in Celcius: %.3f",temp_celc);
    return 0;
}
