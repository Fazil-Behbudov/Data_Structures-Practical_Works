#include <stdio.h>
int main(int argc, char const *argv[])
{
    char ch;
    printf("Enter the character: ");
    ch=getchar(); //Reads the character from the user
    switch(ch){  //we used this instead of if statements.
        case '1':  //checks if the value of ch is '1'
            printf("one");  
            break;
        case '2':  //checks if the value of ch is '2'
            printf("two");
            break;
        case '3':   //checks if the value of ch is '3'
            printf("three");
            break;
        default:    //this line works if non of the previous cases are true.
            printf("other character");
            break;
    }
    return 0;
}
