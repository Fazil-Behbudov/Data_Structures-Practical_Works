#include <stdio.h>
int main(int argc, char const *argv[])
{
    char ch;
    printf("Enter an character: ");
    ch=getchar();  //Reads the character from the user
    if(ch>='0' && ch<='9'){  //checks if the entered character is a number.
        printf("The entered character is a number.");
    }
    else if(ch>='a' && ch<'z'){  //checks if the entered character is a lower case letter
        printf("The entered character is a lower case letter.");
    }
    else if(ch>='A' && ch<'Z'){  //checks if the entered character is a upper case letter
        printf("The entered character is an upper case letter.");
    }
    else{
        printf("The input is not correct.");   //prints this if the character is neither a number nor a upper case letter nor a lower case letter
    }
    return 0;
}
