#include <stdio.h>
int main(int argc, char const *argv[])
{
    int count=0;
    char ch;
    while(1){
        printf("Enter the character: ");
        ch=getchar(); //Reads the character from the user

        //Finds the count of numbers entered by the user
        if(ch>='0' && ch<='9'){ 
            count++;
        }
        // if the character is newline character,exits the loop
        else if(ch == '\n'){   
            break;
        }
        // Consume the extra newline left in the buffer
        while(getchar() !='\n');
    }
    printf("Count of numbers entered by the user: %d",count);
    return 0;
}
