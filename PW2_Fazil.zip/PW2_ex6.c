#include <stdio.h>
int main(int argc, char const *argv[])
{
    float a,b,c,min,max;
    printf("Enter 3 numbers: ");
    scanf("%f%f%f",&a,&b,&c);
    if(a >= b && c >= b ){     // checks if b is smaller than both a and c
        min=b;
        if(a >= c){          //finds the maximum between a and c
            max=a;}
        else{
            max=c;}
    }
    else if(b >= a && c >= a){     // checks if a is smaller than both b and c
        min=a;
        if(b >= c){          //finds the maximum between b and c
            max=b;}
        else{
            max=c;}
    }
    else{                         // works if none of the previous cases are true.
        min=c;
        if(a >= b){         //finds the maximum between a and b
            max=a;}
        else{
            max=b;}
    }
    printf("The smallest number: %.3f\n",min);
    printf("The largest number: %.3f\n",max);
    printf("The sum of three numbers: %.3f\n",a+b+c);
    return 0;
}
