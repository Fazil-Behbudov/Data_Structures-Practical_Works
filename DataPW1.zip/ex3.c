#include <stdio.h>
int main() {
    while(1){
        int num;
        scanf("%d",&num);
        if(num<=0){
            break;}
        else if(num>=1 && num<=100){
            printf("%d",num);
            break;}
        else{
            printf("Enter a new number:");}
    }
    return 0;
}