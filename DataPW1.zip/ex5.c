#include <stdio.h>

int main() {
    float distance=500;int days;
    printf("Enter the number of days: ");
    scanf("%d",&days);
    float merc_co=100,bmw_co=80,tes_co=180;
    float merc_free=250,bmw_free=300,tes_free=250;
    float merc_price=merc_co*days+(distance-merc_free)*1;
    float bmw_price=bmw_co*days+(distance-bmw_free)*1.2;
    float tes_price=tes_co*days+((distance-tes_free)/200)*20;
    printf("Mercedes: %f\nBMW: %f\nTesla: %f\n",merc_price,bmw_price,tes_price);
    if(merc_price<bmw_price &&  merc_price<tes_price){
        printf("Mercedes is the most benefit one.");
    }
    else if(bmw_price<merc_price &&  bmw_price<tes_price){
        printf("BMW is the most benefit one.");
    }
    else if(tes_price<bmw_price &&  tes_price<merc_price){
        printf("Tesla is the most benefit one.");
    }
    else{
        printf("They all cost the same price.");
    }
    return 0;
}