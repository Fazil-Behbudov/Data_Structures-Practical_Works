#include <stdio.h>
int main() {
    int a,b;
    scanf("%d%d",&a,&b);
    if(a>b){
        printf("%d is the greater one",a);}
    else{
        if(a<b){
            printf("%d is the greater one",b);
        }
        else{
            printf("These numbers are equal");
        }
    }
    return 0;
}