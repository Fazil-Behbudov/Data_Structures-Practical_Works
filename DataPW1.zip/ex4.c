#include <stdio.h>
int main() {
    int n;
    printf("Enter the number of grades: ");
    scanf("%d",&n);
    float grade,total=0;
    for(int i=0;i<n;i++){
        printf("Enter grade number %d: ",i+1);
        scanf("%f",&grade);
        total+=grade;}
    float average=total/n;
    printf("Your average is:%f\n",average);
    if(average>=0 && average<=5){
        printf("low average");}
    else if(average>5 && average<=8){
        printf("good average");}
    else{
        printf("excellent average");}
    return 0;
}