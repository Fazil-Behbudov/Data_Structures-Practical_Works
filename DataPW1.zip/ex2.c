#include <stdio.h>
#include <math.h>
int main() {
    float a,b,c;
    scanf("%f%f%f",&a,&b,&c);
    float D=b*b-4*a*c;
    if(D>0){
        float x_1=(-b-sqrt(D))/(2*a);
        float x_2=(-b+sqrt(D))/(2*a);
        printf("The roots are %f and %f",x_1,x_2);}
    else{
        if(D==0){
            float x=(-b-sqrt(D))/(2*a);
            printf("The only root is %f",x);}
        else{
            printf("It has no real roots");}
    }
    return 0;
}