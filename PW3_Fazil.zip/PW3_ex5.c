#include <stdio.h>
#include <stdbool.h>
#include <string.h>
char my_toupper(char x){
    if(x >= 'a' && x <= 'z'){
        x=x-('a'-'A');
    }
    return x;
}
char my_tolower(char x){
    if(x >= 'A' && x <= 'Z'){
        x=x+('a'-'A');
    }
    return x;
}
bool my_strcmp(char x[],char y[]){
    if(strlen(x) != strlen(y)){
        return false;
    }
    char *pX=x;
    char *pY=y;
    int i=0;
    while(*pX != '\0' || *pY != '\0'){
        if(*pX != *pY){
            return false;
        }
        pX++;
        pY++;
    }
    return true;
}

void my_strcat(char *pX,char *pY){
    while(*pX != '\0' && *pX != '\n'){
        pX++;
    }
    while(*pY != '\0' && *pY != '\n'){
        *pX=*pY;
        *pX++;
        *pY++;
    }   
}
void my_strcpy(char *pX,char *pY){
    while(*pY != '\0' && *pY != '\n'){
        *pX=*pY;
        pX++;
        pY++;
    }
    pX++;
}

int main(int argc, char const *argv[])
{
    char str[100];
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    int i=0;
    while(str[i] != '\0'){
        str[i]=my_toupper(str[i]);
        i++;
    }
    printf("The Uppercase version: %s",str);
    int j=0;
    while(str[j] != '\0'){
        str[j]=my_tolower(str[j]);
        j++;
    }
    printf("The Lowercase version: %s\n",str);
    char x[100],y[100];
    printf("Enter 2 new strings: ");
    fgets(x, sizeof(x), stdin);
    fgets(y, sizeof(y), stdin);
    bool cmp=my_strcmp(x,y);
    if(cmp == true){
        printf("The entered strings are same\n\n");
    }
    else{
        printf("The entered is strings are not same\n\n");
    }
    char concenated[100];
    strcpy(concenated,x);
    my_strcat(concenated,y);
    printf("The concenated version of string is: %s\n",concenated);
    char cpy[100];
    strcpy(cpy,x);
    my_strcpy(cpy,y);
    printf("The copied string is: %s\n",cpy);

   
    return 0;
}
