#include <stdio.h>
int my_isalpha(char c){
    if((c >= 'a' && c <= 'z') || (c >= 'A' && c <='Z')){
        return 1;
    }
    else{
        return 0;
    }
}
int my_isdigit(char c){
    if(c >= '0' && c <= '9'){
        return 1;
    }
    else{
        return 0;
    }
}
int main(int argc, char const *argv[])
{
    char ch;
    printf("Enter a character: ");
    scanf("%c",&ch);
    if(my_isalpha(ch) == 1){
        printf("%c is a letter.",ch);
    }
    else if(my_isdigit(ch) == 1){
        printf("%c is a number.",ch);
    }
    else{
        printf("%c is neither a number nor a letter.",ch);
    }
    return 0;
}
