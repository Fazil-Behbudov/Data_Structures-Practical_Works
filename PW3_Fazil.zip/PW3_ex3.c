#include <stdio.h>
int my_strlen(char x[]){
    int length=0;
    int i=0;
    while(x[i] != '\0' && x[i] != '\n'){
        length++;
        i++;
    }
    return length;
}
int main(int argc, char const *argv[])
{
    char str[100];
    printf("Enter a string: ");
    fgets(str, sizeof(str), stdin);
    int len=my_strlen(str);
    printf("The length of the entered string is: %d",len);
    return 0;
}
